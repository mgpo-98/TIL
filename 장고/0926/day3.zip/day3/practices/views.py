from multiprocessing import context
from unicodedata import name
from django.shortcuts import render

# Create your views here.
def index(request):
    return render(request,'index.html')


def ping(request):
    return render(request, 'ping.html')

def pong(request):
    # print(request)
    # print(dir(request))
    ball = request.GET.get('ball')
    context ={
        'name' : ball,
    }

    return render(request, 'pong.html',context)