from django.shortcuts import render
import random

# Create your views here.
def index(request):
    return render(request, "index.html")


def life(request):
    return render(request, "life-ago.html")


def judge(request, id):

    if id % 2 == 0:
        res = "짝수"
    else:
        res = "홀수"

    context = {"res": res, "id": id}

    return render(request, "judge.html", context)


def calculator(request, var1, var2):

    if var2 == 0:
        return render(request, "error.html")

    res_sum = var1 + var2
    res_sub = var1 - var2
    res_mul = var1 * var2
    res_div = var1 // var2

    context = {
        "sum": res_sum,
        "sub": res_sub,
        "mul": res_mul,
        "div": res_div,
        "var1": var1,
        "var2": var2,
    }

    return render(request, "cal.html", context)


def show(request):
    name = request.GET.get("name")
    prevs = ["왕", "추노꾼", "선비", "장원급제 엘리트", "천하대장군", "거북선 조타수"]
    imgs = {
        "왕": "http://www.news-paper.co.kr/news/photo/201806/27789_12522_1416.jpg",
        "추노꾼": "https://cdn.newscj.com/data2/content/image/2010/02/17/.cache/512/201002170031187.jpg",
        "선비": "https://mblogthumb-phinf.pstatic.net/20160415_200/ohsgoat_1460663733315qj7Qc_JPEG/%BC%B1%BA%F1%B0%AB2.jpg?type=w2",
        "장원급제 엘리트": "https://t1.daumcdn.net/cfile/blog/2735684B5187427F01",
        "천하대장군": "https://w.namu.la/s/5f2b41ca7159dab9d1c59ca253773a22658b1449b5828a10562dbdc323b4dc741d6e6c286e93f4321f6493a5e32f81fe85a69b67e9fb9502db339b31a83883d77adc1d917cec113eb2bfaed61b7c63e0b7040df60d5a90853d6eb6ee5efda65b",
        "거북선 조타수": "https://t1.daumcdn.net/cfile/tistory/176CBA4D4F8274F924",
    }

    prev = random.choice(prevs)
    context = {"name": name, "before": prev, "img": imgs.get(prev)}

    return render(request, "life-ago-show.html", context)


def lorem(request):
    return render(request, "lorem.html")


def loremShow(request):
    cnt_para = int(request.GET.get("para"))
    cnt_words = int(request.GET.get("words"))

    # lorems = [[] for _ in range(cnt_para)]
    lorems = [[] for _ in range(cnt_para)]
    ran_words = [
        "바나나",
        "짜장면",
        "사과",
        "바나나",
        "딸기",
    ]

    for i in range(len(lorems)):
        while len(lorems[i]) < cnt_words:
            word = random.choice(ran_words)
            lorems[i].append(word)

    context = {"lorems": lorems}
    return render(request, "lorem-show.html", context)