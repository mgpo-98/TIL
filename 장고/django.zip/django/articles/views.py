import imp
from turtle import title
from django.shortcuts import render, redirect

import articles
from articles.forms import ArticleForm, ArticlesForm
from .models import Article
from .forms import ArticleForm
# Create your views here.

#요청 정보를 받아서
def index(request):
    #게시글을 가져와서
    articles = Article.objects.order_by('-pk')
    context = {
        'articles': articles
    }
 
    

    return render(request, 'articles/index.html',context)
# temlape에 전달한다.
  
def new(request):
    article_form = ArticleForm()
    context = {
        'article_form': article_form
    }

    return render(request,'articles/new.html', context=context)
def create(request):
   if request.method == 'POST' :#DB에 저장하는 로직
        article_form = ArticleForm(request.POST)
        if article_form.is_valid():
            article_form.save()
            return redirect('articles:index')
    else:
        article_form = ArticleForm()
    context = {
        'article_form' : article_form
    }
    return render(request, 'articles/new.html', context=context)

def detail(request, pk):
    # 특정 글을 가져온다
    article = Article.objects.get(pk=pk)
    # template에 객체 던달
    context = {
        'article' : article
    }
    return render(request, 'articles/detail.html', context)

def update(request, pk):
    article = Article.objects.get(pk=pk)
    if request.method == 'POST':
        # POST :input 값 가져와서, 검증하고 DB
        article_form = ArticleForm(request.POST)
        if article_form.is_valid():