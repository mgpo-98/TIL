
from django.shortcuts import render
import random
# HTTP: 요청(request)을 하면 무언가를 응답(response)하는 방식
# Create your views here.
# index 함수 선언 정의
def index(request):
        
    
    return render(request,'index.html')


def template(requsets):

    dinners =['삼겹살','막창','치킨','갈비찜','곱도리탕','낙곱새','족발','부대찌개','곱창전골','곱창']
    dinner_img ={
            '삼겹살':'https://src.hidoc.co.kr/image/lib/2021/8/27/1630049987719_0.jpg',
            '막창' : 'https://cdn.pttimes.com/news/photo/201804/45229_46100_481.jpg',
            '치킨' :'https://kfcapi.inicis.com/kfcs_api_img/KFCS/goods/DL_2175525_20220630163907792.png',
            '갈비찜':'https://recipe1.ezmember.co.kr/cache/recipe/2016/12/13/0f12719bc6d713fd727d5f1cd65ad6141.jpg',
            '곱도리탕':'https://crcf.cookatmarket.com/product/images/2019/12/lupo_1575453086_9938_720.jpg',
            '낙곱새':'https://thingool123.godohosting.com/data/goods/20/11/45/1000016357/1000016357_detail_053.jpg',
            '족발':'https://static.hubzum.zumst.com/hubzum/2019/07/26/11/8291a05e16b14e9b91eedc7a4375c934_780x585.jpg',
            '부대찌개':'https://static.wtable.co.kr/image/production/service/product/9425/e4bea539-74ee-4437-9928-bd015f04ed3f.jpg',
            '곱창전골':'http://th4.tmon.kr/thumbs/image/897/1e3/407/433c264cc_700x700_95_FIT.jpg',
            '곱창':'http://gdimg.gmarket.co.kr/1638958859/still/600?ver=1639450670'

    }
    dinner = random.choice(dinners)
    
    context ={
        'dinner': dinner,
        'img': dinner_img[dinner]
    }
    return render(requsets,'template.html', context)